// Stub for Moodify component (excluded from Firefox build)
export default function Moodify() {
  return null
}
