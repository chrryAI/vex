/**
 * Extension-specific navigation
 * Re-exports from navigation.extension instead of navigation.web
 */

export * from "../../../../packages/ui/platform/navigation.extension"
