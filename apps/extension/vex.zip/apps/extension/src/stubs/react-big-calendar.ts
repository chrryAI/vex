// Stub for react-big-calendar (excluded from Firefox build)
export const Calendar = () => null
export const momentLocalizer = () => null
export default Calendar
