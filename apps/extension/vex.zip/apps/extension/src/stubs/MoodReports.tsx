// Stub for MoodReports component (excluded from Firefox build)
export default function MoodReports() {
  return null
}
