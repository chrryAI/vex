// Stub for Focus component (excluded from Firefox build)
export default function Focus() {
  return null
}
