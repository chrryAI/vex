// Stub for Calendar component (excluded from Firefox build)
export default function Calendar() {
  return null
}
