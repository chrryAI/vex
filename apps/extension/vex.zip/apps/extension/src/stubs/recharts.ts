// Stub for recharts (excluded from Firefox build)
export const LineChart = () => null
export const Line = () => null
export const XAxis = () => null
export const YAxis = () => null
export const CartesianGrid = () => null
export const Tooltip = () => null
export const Legend = () => null
export const ResponsiveContainer = () => null
export const BarChart = () => null
export const Bar = () => null
export const PieChart = () => null
export const Pie = () => null
export const Cell = () => null
export const AreaChart = () => null
export const Area = () => null
