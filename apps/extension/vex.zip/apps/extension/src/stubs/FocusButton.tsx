// Stub for FocusButton component (excluded from Firefox build)
export default function FocusButton() {
  return null
}
