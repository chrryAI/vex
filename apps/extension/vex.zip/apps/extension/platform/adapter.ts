import type { PlatformAdapter } from "@repo/shared/platform/types"

export const extensionPlatform: PlatformAdapter = {
  storage: {
    getString: (key: string) => {
      // Chrome storage is async, but we'll use a sync wrapper
      let result: string | undefined
      chrome.storage.local.get([key], (data) => {
        result = data[key]
      })
      return result
    },
    setString: (key: string, value: string) => {
      chrome.storage.local.set({ [key]: value })
    },
    getBoolean: (key: string) => {
      let result: boolean | undefined
      chrome.storage.local.get([key], (data) => {
        result = data[key]
      })
      return result
    },
    setBoolean: (key: string, value: boolean) => {
      chrome.storage.local.set({ [key]: value })
    },
    getNumber: (key: string) => {
      let result: number | undefined
      chrome.storage.local.get([key], (data) => {
        result = data[key]
      })
      return result
    },
    setNumber: (key: string, value: number) => {
      chrome.storage.local.set({ [key]: value })
    },
    delete: (key: string) => {
      chrome.storage.local.remove([key])
    },
    clearAll: () => {
      chrome.storage.local.clear()
    },
    getAllKeys: () => {
      let keys: string[] = []
      chrome.storage.local.get(null, (items) => {
        keys = Object.keys(items)
      })
      return keys
    },
  },

  notifications: {
    show: (message, options) => {
      chrome.notifications.create({
        type: "basic",
        iconUrl: chrome.runtime.getURL("icon.png"),
        title: options?.title || "Vex",
        message,
      })
    },
  },

  navigation: {
    navigate: (path: string) => {
      chrome.tabs.create({ url: `https://askvex.com${path}` })
    },
    goBack: () => {
      window.history.back()
    },
    replace: (path: string) => {
      window.location.replace(path)
    },
  },

  clipboard: {
    copy: async (text: string) => {
      await navigator.clipboard.writeText(text)
    },
    paste: async () => {
      return await navigator.clipboard.readText()
    },
  },

  platform: {
    type: "extension",
    os: "web",
  },
}
