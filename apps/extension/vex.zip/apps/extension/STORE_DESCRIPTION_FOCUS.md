# Focus - AI-Powered Productivity Assistant

## 🎯 What is Focus?

Focus is your AI-powered productivity companion that helps you stay on track, manage tasks, and achieve your goals. Built with a beautiful Pomodoro timer, mood tracking, and intelligent AI assistance, Focus transforms how you work and stay productive.

## ✨ Key Features:

**⏱️ Smart Pomodoro Timer:**
• Customizable work/break intervals
• Visual progress tracking
• Session history and analytics
• Automatic task time logging

**✅ Intelligent Task Management:**
• Create and organize tasks with AI assistance
• Track time spent on each task
• Thread-based task conversations
• Progress tracking and completion stats

**😊 Mood & Wellness Tracking:**
• Log your mood throughout the day
• Visualize emotional patterns
• Understand productivity correlations
• Build self-awareness habits

**🤖 AI-Powered Assistance:**
• Ask questions about your tasks and progress
• Get productivity insights and suggestions
• Analyze your work patterns
• Receive personalized recommendations

**📊 Progress Analytics:**
• Daily, weekly, and monthly reports
• Time tracking across all tasks
• Mood distribution insights
• Productivity trends and patterns

## 🎨 Beautiful & Intuitive:

• Clean, distraction-free interface
• Dark mode support
• Smooth animations and transitions
• Sidebar access - work without leaving your current page

## 🔒 Privacy-Focused:

• Your data stays private and secure
• True data deletion when you delete tasks
• Transparent cost tracking
• No hidden fees or surprise charges

## 🎁 Flexible Pricing:

• **Guest Access** - Try it free, no account required
• **Member Access** - Access to Sushi, Claude, Gemini, ChatGPT and Perplexity

• **Plus (€9.99/mo)** - 2000 AI message credits,  advanced analytics
• **Pro (€19.99/mo)** - 5000 AI message credits, Priority access, team features
• **Pay-as-you-go** - Buy credits when you need them

**Why install Focus?** Combine the proven Pomodoro technique with AI-powered task management and mood tracking. Stay focused, understand your productivity patterns, and achieve more with intelligent assistance right in your browser sidebar.

Perfect for students, professionals, freelancers, and anyone who wants to work smarter and stay mindful of their wellbeing.

Start with guest access - no account required. Upgrade anytime for unlimited features.

---

## Store Submission Details

### Short Description (132 characters max):

AI-powered Pomodoro timer with task management and mood tracking. Stay focused, productive, and mindful while you work.

### Detailed Description:

Use the full description above, formatted appropriately for each store's requirements.

### Keywords:

Pomodoro timer, productivity, task management, mood tracking, focus, time tracking, AI assistant, work timer, break timer, productivity tracker, wellbeing, mindfulness, browser extension

### Category:

- Chrome Web Store: Productivity
- Firefox Add-ons: Productivity

### Permissions Justification:

**Storage:** Save your tasks, timer settings, mood logs, and preferences locally
**Side Panel:** Display the Focus interface in your browser sidebar for easy access
**Tabs:** Detect current page context for task-related assistance
**Context Menus:** Right-click integration for quick task creation
**Host Permissions (focus.chrry.ai, chrry.dev):** Connect to Focus AI services and sync your data
