// This file serves as the main entry point for EnableNotifications
// React Native's Metro bundler will automatically resolve to:
// - EnableNotifications.web.tsx for web
// - EnableNotifications.native.tsx for React Native

export { default } from "./EnableNotifications.web"
