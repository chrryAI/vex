/**
 * Auto-generated responsive styles with breakpoint support
 * Generated: 2025-10-18T13:29:16.297Z
 */

export const StyleDefs = {
  lifeOS: {
    display: "flex",
    direction: "column",
    gap: "toRem.toRem(10)",
    bottom: "toRem.toRem(5)",
    size: "toRem.toRem(20)",
    items: "center",
    margin: 0,
    flex: 1,
    align: "center",
  },
  intro: {
    align: "center",
    size: "toRem.toRem(14)",
    width:
      "breakpoints.$breakpoint-mobile) {\n        font-size: toRem.toRem(15)",
  },
  content: {
    display: "flex",
    direction: "column",
    gap: "toRem.toRem(15)",
  },
  createAgent: {
    display: "flex",
    content: "center",
    position: "relative",
    bottom: "toRem.toRem(10)",
  },
  apps: {
    display: "flex",
    items: "center",
    gap: "toRem.toRem(15)",
    content: "center",
    top: "toRem.toRem(10)",
    wrap: "wrap",
  },
  titleText: {
    display: "flex",
    items: "center",
    gap: "toRem.toRem(5)",
    align: "center",
    flex: 1,
    self: "center",
    content: "center",
    weight: 600,
  },
  headerIcons: {
    display: "flex",
    items: "center",
    gap: "toRem.toRem(7.5)",
    bottom: "toRem.toRem(10)",
  },
  app: {
    position: "relative",
    display: "flex",
    items: "center",
    direction: "column",
    gap: "toRem.toRem(10)",
    outline: "1px dashed var(--shade-2)",
    padding: "toRem.toRem(10)",
    top: "toRem.toRem(12.5)",
    radius: "toRem.toRem(20)",
    cursor: "pointer",
    transition: "all 0.2s ease-in-out",
    width: "breakpoints.$breakpoint-mobile) {\n    flex: inherit",
    flex: 1,
  },
  selected: {
    outline: "3px solid var(--accent-5)",
    color: "var(--shade-1)",
  },
  appInfo: {
    display: "flex",
    direction: "column",
    gap: "toRem.toRem(2)",
    size: "toRem.toRem(16)",
    weight: 600,
    align: "center",
  },
  appSubtitle: {
    size: "toRem.toRem(12)",
    color: "var(--shade-5)",
    align: "center",
    weight: 400,
    width: "toRem.toRem(120)",
    overflow: "ellipsis",
    space: "nowrap",
  },
  badge: {
    bottom: "toRem.toRem(10)",
    right: 1,
    color: "var(--accent-5)",
    padding: "toRem.toRem(3) toRem.toRem(10)",
    radius: "toRem.toRem(20)",
    size: "toRem.toRem(12)",
  },
  planned: {
    color: "var(--shade-3)",
  },
  footer: {
    padding: "toRem.toRem(15)",
    background: "var(--shade-1)",
    radius: "toRem.toRem(20)",
    border: "1px dashed var(--shade-2)",
    animation: "slideUp 0.4s ease forwards",
    margin: "0 0 toRem.toRem(10) 0",
    size: "toRem.toRem(24)",
    weight: 600,
  },
  subtitle: {
    margin: "0 0 toRem.toRem(5) 0",
    color: "var(--accent-1)",
    weight: 500,
    size: "toRem.toRem(16)",
  },
  description: {
    margin: "0 0 toRem.toRem(20) 0",
    height: 1.6,
    color: "var(--shade-7)",
    size: "toRem.toRem(15)",
  },
  features: {
    margin: "0 0 toRem.toRem(10) 0",
    size: "toRem.toRem(16)",
    weight: 600,
  },
  feature: {
    display: "flex",
    items: "center",
    gap: "toRem.toRem(5)",
  },
  tetris: {
    display: "flex",
    content: "center",
    items: "center",
    top: "toRem.toRem(20)",
    gap: "toRem.toRem(10)",
    direction: "column",
    size: "toRem.toRem(12)",
  },
} as const

import { createUnifiedStyles } from "@repo/ui/styles/createUnifiedStyles"
import { createStyleHook } from "@repo/ui/styles/createStyleHook"

export const Styles = createUnifiedStyles(StyleDefs)

type StylesHook = {
  [K in keyof typeof StyleDefs]: {
    className?: string
    style?: Record<string, any>
  }
}

export const useStyles = createStyleHook<StylesHook>(Styles)
