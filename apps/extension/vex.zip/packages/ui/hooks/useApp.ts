/**
 * Modern hook that uses Zustand stores instead of Context API
 * This is the recommended way to access app state going forward
 */

import {
  useAuthStore,
  usePersonalizationStore,
  useDeviceStore,
  useChatStore,
  useThreadsStore,
  useAppStore,
  useCreditsStore,
  useAudioStore,
  useProfileStore,
  useAffiliateStore,
  useRouterStore,
  useUIStore,
} from "@repo/shared/stores"
import { useTranslation } from "react-i18next"
import { useTheme } from "next-themes"
import { trackEvent } from "../utils"

/**
 * Main app hook using Zustand stores
 * Use this instead of useAppContext for new code
 */
export function useApp() {
  const { t } = useTranslation()
  const { theme, setTheme } = useTheme()

  // Auth
  const user = useAuthStore((s) => s.user)
  const guest = useAuthStore((s) => s.guest)
  const token = useAuthStore((s) => s.token)
  const fingerprint = useAuthStore((s) => s.fingerprint)
  const isLoading = useAuthStore((s) => s.isLoading)
  const setUser = useAuthStore((s) => s.setUser)
  const setGuest = useAuthStore((s) => s.setGuest)
  const signOut = useAuthStore((s) => s.signOut)
  const fetchSession = useAuthStore((s) => s.fetchSession)

  // Device
  const deviceId = useDeviceStore((s) => s.deviceId)
  const isStandalone = useDeviceStore((s) => s.isStandalone)
  const isExtension = useDeviceStore((s) => s.isExtension)
  const isSmallDevice = useDeviceStore((s) => s.isSmallDevice)
  const isMobileDevice = useDeviceStore((s) => s.isMobileDevice)
  const addHapticFeedback = useDeviceStore((s) => s.addHapticFeedback)

  // Personalization
  const selectedAgent = usePersonalizationStore((s) => s.selectedAgent)
  const debateAgent = usePersonalizationStore((s) => s.debateAgent)
  const aiAgents = usePersonalizationStore((s) => s.aiAgents)
  const isWebSearchEnabled = usePersonalizationStore(
    (s) => s.isWebSearchEnabled,
  )
  const setSelectedAgent = usePersonalizationStore((s) => s.setSelectedAgent)
  const setIsWebSearchEnabled = usePersonalizationStore(
    (s) => s.setIsWebSearchEnabled,
  )
  const language = usePersonalizationStore((s) => s.language)
  const color = usePersonalizationStore((s) => s.color)
  const reduceMotion = usePersonalizationStore((s) => s.reduceMotion)
  const setColor = usePersonalizationStore((s) => s.setColor)
  const setReduceMotion = usePersonalizationStore((s) => s.setReduceMotion)
  const enableSound = usePersonalizationStore((s) => s.enableSound)
  const setEnableSound = usePersonalizationStore((s) => s.setEnableSound)
  const characterProfilesEnabled = usePersonalizationStore(
    (s) => s.characterProfilesEnabled,
  )
  const memoriesEnabled = usePersonalizationStore((s) => s.memoriesEnabled)
  const setCharacterProfilesEnabled = usePersonalizationStore(
    (s) => s.setCharacterProfilesEnabled,
  )
  const setMemoriesEnabled = usePersonalizationStore(
    (s) => s.setMemoriesEnabled,
  )

  // Chat
  const thread = useChatStore((s) => s.thread)
  const threadId = useChatStore((s) => s.threadId)
  const isNewChat = useChatStore((s) => s.isNewChat)
  const newChatTrigger = useChatStore((s) => s.newChatTrigger)
  const isDebating = useChatStore((s) => s.isDebating)
  const isEmpty = useChatStore((s) => s.isEmpty)
  const isChatFloating = useChatStore((s) => s.isChatFloating)
  const isIncognito = useChatStore((s) => s.isIncognito)
  const wasIncognito = useChatStore((s) => s.wasIncognito)
  const reactedMessages = useChatStore((s) => s.reactedMessages)
  const shouldRefetchThread = useChatStore((s) => s.shouldRefetchThread)
  const isShowingCollaborate = useChatStore((s) => s.isShowingCollaborate)
  const collaborationStep = useChatStore((s) => s.collaborationStep)
  const collaborationStatus = useChatStore((s) => s.collaborationStatus)
  const setThread = useChatStore((s) => s.setThread)
  const setThreadId = useChatStore((s) => s.setThreadId)
  const setIsNewChat = useChatStore((s) => s.setIsNewChat)
  const setIsDebating = useChatStore((s) => s.setIsDebating)
  const setIsEmpty = useChatStore((s) => s.setIsEmpty)
  const setIsChatFloating = useChatStore((s) => s.setIsChatFloating)
  const setIsIncognito = useChatStore((s) => s.setIsIncognito)
  const setWasIncognito = useChatStore((s) => s.setWasIncognito)
  const setReactedMessages = useChatStore((s) => s.setReactedMessages)
  const setShouldRefetchThread = useChatStore((s) => s.setShouldRefetchThread)
  const setIsShowingCollaborate = useChatStore((s) => s.setIsShowingCollaborate)
  const setCollaborationStep = useChatStore((s) => s.setCollaborationStep)
  const setCollaborationStatus = useChatStore((s) => s.setCollaborationStatus)

  // Threads
  const threads = useThreadsStore((s) => s.threads)
  const isLoadingThreads = useThreadsStore((s) => s.isLoadingThreads)
  const activeCollaborationThreadsCount = useThreadsStore(
    (s) => s.activeCollaborationThreadsCount,
  )
  const pendingCollaborationThreadsCount = useThreadsStore(
    (s) => s.pendingCollaborationThreadsCount,
  )
  const setThreads = useThreadsStore((s) => s.setThreads)
  const fetchThreads = useThreadsStore((s) => s.fetchThreads)
  const refetchThreads = useThreadsStore((s) => s.refetchThreads)
  const fetchActiveCollaborationThreadsCount = useThreadsStore(
    (s) => s.fetchActiveCollaborationThreadsCount,
  )
  const fetchPendingCollaborationThreadsCount = useThreadsStore(
    (s) => s.fetchPendingCollaborationThreadsCount,
  )

  // App
  const apps = useAppStore((s) => s.apps)
  const app = useAppStore((s) => s.app)
  const appName = useAppStore((s) => s.appName)
  const instructions = useAppStore((s) => s.instructions)
  const setApp = useAppStore((s) => s.setApp)
  const setAppName = useAppStore((s) => s.setAppName)

  // Credits
  const creditsLeft = useCreditsStore((s) => s.creditsLeft)
  const hourlyLimit = useCreditsStore((s) => s.hourlyLimit)
  const hourlyUsageLeft = useCreditsStore((s) => s.hourlyUsageLeft)
  const hitHourlyLimit = useCreditsStore((s) => s.hitHourlyLimit)
  const messagesLastHour = useCreditsStore((s) => s.messagesLastHour)

  // Audio
  const playNotification = useAudioStore((s) => s.playNotification)
  const playHardPopClick = useAudioStore((s) => s.playHardPopClick)
  const playLongPop = useAudioStore((s) => s.playLongPop)
  const playSillyPopCluster = useAudioStore((s) => s.playSillyPopCluster)
  const playWorkout = useAudioStore((s) => s.playWorkout)

  // Profile
  const profile = useProfileStore((s) => s.profile)
  const userNameByUrl = useProfileStore((s) => s.userNameByUrl)
  const isVisitor = useProfileStore((s) => s.isVisitor)
  const setProfile = useProfileStore((s) => s.setProfile)

  // Affiliate
  const affiliateCode = useAffiliateStore((s) => s.affiliateCode)
  const affiliateStats = useAffiliateStore((s) => s.affiliateStats)
  const loadingAffiliateStats = useAffiliateStore(
    (s) => s.loadingAffiliateStats,
  )
  const refetchAffiliateData = useAffiliateStore((s) => s.refetchAffiliateStats)

  // Router
  const pathname = useRouterStore((s) => s.pathname)
  const searchParams = useRouterStore((s) => s.searchParams)
  const addParam = useRouterStore((s) => s.addParam)
  const removeParam = useRouterStore((s) => s.removeParam)

  // UI
  const isDrawerOpen = useUIStore((s) => s.isDrawerOpen)
  const isAccountVisible = useUIStore((s) => s.isAccountVisible)
  const isMemoryConsentManageVisible = useUIStore(
    (s) => s.isMemoryConsentManageVisible,
  )
  const showAddToHomeScreen = useUIStore((s) => s.showAddToHomeScreen)
  const showCharacterProfiles = useUIStore((s) => s.showCharacterProfiles)
  const isHome = useUIStore((s) => s.isHome)
  const signInPart = useUIStore((s) => s.signInPart)
  const hasNotification = useUIStore((s) => s.hasNotification)
  const setIsDrawerOpen = useUIStore((s) => s.setIsDrawerOpen)
  const setIsAccountVisible = useUIStore((s) => s.setIsAccountVisible)
  const setIsMemoryConsentManageVisible = useUIStore(
    (s) => s.setIsMemoryConsentManageVisible,
  )
  const setShowAddToHomeScreen = useUIStore((s) => s.setShowAddToHomeScreen)
  const setShowCharacterProfiles = useUIStore((s) => s.setShowCharacterProfiles)
  const setIsHome = useUIStore((s) => s.setIsHome)
  const setSignInPart = useUIStore((s) => s.setSignInPart)

  // Helpers
  const track = trackEvent

  return {
    // Auth
    user,
    guest,
    token,
    fingerprint,
    isLoading,
    setUser,
    setGuest,
    signOut,
    fetchSession,

    // Device
    deviceId,
    isStandalone,
    isExtension,
    isSmallDevice,
    isMobileDevice,
    addHapticFeedback,

    // Personalization
    selectedAgent,
    debateAgent,
    aiAgents,
    isWebSearchEnabled,
    setSelectedAgent,
    setIsWebSearchEnabled,
    language,
    color,
    reduceMotion,
    setColor,
    setReduceMotion,
    enableSound,
    setEnableSound,
    characterProfilesEnabled,
    memoriesEnabled,
    setCharacterProfilesEnabled,
    setMemoriesEnabled,

    // Chat
    thread,
    threadId,
    isNewChat,
    newChatTrigger,
    isDebating,
    isEmpty,
    isChatFloating,
    isIncognito,
    wasIncognito,
    reactedMessages,
    shouldRefetchThread,
    isShowingCollaborate,
    collaborationStep,
    collaborationStatus,
    setThread,
    setThreadId,
    setIsNewChat,
    setIsDebating,
    setIsEmpty,
    setIsChatFloating,
    setIsIncognito,
    setWasIncognito,
    setReactedMessages,
    setShouldRefetchThread,
    setIsShowingCollaborate,
    setCollaborationStep,
    setCollaborationStatus,

    // Threads
    threads,
    isLoadingThreads,
    activeCollaborationThreadsCount,
    pendingCollaborationThreadsCount,
    setThreads,
    fetchThreads,
    refetchThreads,
    fetchActiveCollaborationThreadsCount,
    fetchPendingCollaborationThreadsCount,

    // App
    apps,
    app,
    appName,
    instructions,
    setApp,
    setAppName,

    // Credits
    creditsLeft,
    hourlyLimit,
    hourlyUsageLeft,
    hitHourlyLimit,
    messagesLastHour,

    // Audio
    playNotification,
    playHardPopClick,
    playLongPop,
    playSillyPopCluster,
    playWorkout,

    // Profile
    profile,
    userNameByUrl,
    isVisitor,
    setProfile,

    // Affiliate
    affiliateCode,
    affiliateStats,
    loadingAffiliateStats,
    refetchAffiliateData,

    // Router
    pathname,
    searchParams,
    addParam,
    removeParam,

    // UI
    isDrawerOpen,
    isAccountVisible,
    isMemoryConsentManageVisible,
    showAddToHomeScreen,
    showCharacterProfiles,
    isHome,
    signInPart,
    hasNotification,
    setIsDrawerOpen,
    setIsAccountVisible,
    setIsMemoryConsentManageVisible,
    setShowAddToHomeScreen,
    setShowCharacterProfiles,
    setIsHome,
    setSignInPart,

    // Utils
    t,
    track,
    theme,
    setTheme,
  }
}
