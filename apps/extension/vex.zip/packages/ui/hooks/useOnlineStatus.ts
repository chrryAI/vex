import { useState, useEffect } from "react"
import { FRONTEND_URL } from "../utils"

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== "undefined" ? navigator.onLine : true, // default to true on server
  )
  useEffect(() => {
    // Skip if window or addEventListener is not available (React Native)
    if (typeof window === "undefined" || !window.addEventListener) {
      return
    }

    function updateStatus() {
      setIsOnline(navigator.onLine)
    }

    window.addEventListener("online", updateStatus)
    window.addEventListener("offline", updateStatus)

    async function checkConnection() {
      try {
        // Check API health endpoint to detect server outages
        const response = await fetch(`${FRONTEND_URL}/api/health`, {
          method: "HEAD",
          cache: "no-store",
        })
        if (response.ok) {
          setIsOnline(true)
        } else {
          setIsOnline(false)
        }
      } catch {
        setIsOnline(false)
      }
    }

    // Initial check in case navigator.onLine is wrong
    checkConnection()

    // Recheck every 30s to detect server outages
    const interval = setInterval(checkConnection, 30000)

    return () => {
      if (window.removeEventListener) {
        window.removeEventListener("online", updateStatus)
        window.removeEventListener("offline", updateStatus)
      }
      clearInterval(interval)
    }
  }, [])

  return isOnline
}
