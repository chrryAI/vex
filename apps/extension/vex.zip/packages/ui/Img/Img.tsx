"use client"

import React, { useState, useEffect } from "react"
import { useInView } from "react-intersection-observer"
import clsx from "clsx"

import styles from "./Img.module.scss"
import Loading from "../Loading"
import { ImageIcon } from "lucide-react"

interface ImgProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  width: number | string
  height?: number | string
  src: string
  alt?: string
  className?: string
  containerClass?: string
  dataTestId?: string
  style?: React.CSSProperties
  showLoading?: boolean
  handleDimensionsChange?: (dimensions: {
    width: number
    height: number
  }) => void
}

export default function Img({
  src,
  alt,
  width,
  height,
  containerClass,
  className,
  style,
  dataTestId,
  handleDimensionsChange,
  showLoading = true,
  ...props
}: ImgProps) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [imageSrc, setImageSrc] = useState<string | null>(null)

  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0,
  })

  const loadImage = async (url: string) => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch(url)
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const img = new Image()

      const blob = await response.blob()
      img.src = URL.createObjectURL(blob)

      try {
        await img.decode()

        const width = img.width
        const height = img.height

        handleDimensionsChange?.({ width, height })
      } catch (e) {}

      setImageSrc(img.src)
    } catch (e) {
      setError("An error occurred while loading image.")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    // Reset state when src changes to force reload
    if (src) {
      setImageSrc(null)
      setError(null)
    }
  }, [src])

  useEffect(() => {
    if (inView && !imageSrc && !error) {
      loadImage(src)
    }
  }, [inView, imageSrc, error, src])

  useEffect(() => {
    return () => {
      if (imageSrc) {
        URL.revokeObjectURL(imageSrc)
      }
    }
  }, [imageSrc])

  if (imageSrc) {
    const imgProps = {
      ...props,
      src: imageSrc,
      alt,
      style: { ...style, width, height },
      onLoad: () => {
        setIsLoaded(true)
      },
    }

    return (
      <img
        data-testid={dataTestId}
        ref={ref}
        className={clsx(styles.img, className, {
          [styles.loaded!]: isLoaded,
        })}
        {...imgProps}
      />
    )
  }

  if (error) return <ImageIcon width={width} height={height} />

  return (
    <div
      ref={ref}
      className={clsx(styles.container, containerClass)}
      style={{ width, height }}
    >
      {isLoading && showLoading && (
        <div className={styles.loadingPlaceholder}>
          <Loading />
        </div>
      )}
    </div>
  )
}
