import registerServiceWorker, {
  subscribeToPushNotifications,
} from "./registerServiceWorker"

export default registerServiceWorker
export { subscribeToPushNotifications }
