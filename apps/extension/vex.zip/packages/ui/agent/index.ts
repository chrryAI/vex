import Agent from "./Agent"

export default Agent
