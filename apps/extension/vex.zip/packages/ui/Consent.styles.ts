/**
 * Generated from Consent.module.scss
 * Auto-converted SCSS to Unified Styles
 *
 * Works on both web and native! 🎉
 */

export const ConsentStyleDefs = {
  cookieConsent: {
    display: "flex",
    flexDirection: "column",
    gap: 15,
    maxWidth: 420,
    borderRadius: "var(--radius)",
    fontSize: 15,
    margin: "5px auto 15px auto",
    position: "relative",
  },
  cookieConsentManage: {
    border: "1px solid var(--shade-2)",
    padding: "10px 15px",
    backgroundColor: "var(--shade-1)",
  },
  productHuntBadge: {
    display: "flex",
    flexDirection: "column",
    gap: 15,
    fontSize: 15,
    margin: "5px auto 15px auto",
    position: "relative",
  },
  options: {
    display: "flex",
    gap: 10,
    flexDirection: "column",
    fontSize: 14,
  },
  buttons: {
    display: "inline-flex",
    flexWrap: "wrap",
    gap: 5,
    alignItems: "center",
    justifyContent: "center",
    padding: "0.45rem 0.55rem",
  },
  content: {
    display: "flex",
    margin: 0,
    alignItems: "flex-start",
  },
  cookie: {
    fontSize: 22,
    marginRight: 10,
  },
} as const

import { createUnifiedStyles } from "@repo/ui/styles/createUnifiedStyles"
import { createStyleHook } from "@repo/ui/styles/createStyleHook"

export const ConsentStyles = createUnifiedStyles(ConsentStyleDefs)

// Type for the hook return value
type ConsentStylesHook = {
  [K in keyof typeof ConsentStyleDefs]: {
    className?: string
    style?: Record<string, any>
  }
}

// Create the style hook using the factory
export const useConsentStyles =
  createStyleHook<ConsentStylesHook>(ConsentStyles)
