// // packages/ui/src/styles/responsive.ts
// export const responsiveValues = {
//   // For properties that need different values per platform
//   fontSize: {
//     h1: {
//       web: "clamp(1.2rem, 4vw, 1.625rem)",
//       native: 26,
//     },
//     h2: {
//       web: "clamp(1rem, 3vw, 1.5rem)",
//       native: 24,
//     },
//     body: {
//       web: "1rem",
//       native: 16,
//     },
//   },
// }

// export function getResponsiveValue(
//   property: string,
//   key: string,
//   platform: "web" | "native",
// ): any {
//   return responsiveValues[property]?.[key]?.[platform]
// }
