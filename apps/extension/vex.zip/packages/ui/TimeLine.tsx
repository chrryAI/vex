"use client"

import React, { useEffect, useRef, ReactNode, useMemo } from "react"

import clsx from "clsx"

import { animate, stagger } from "motion"
import { motion, AnimatePresence } from "framer-motion"
import { usePathname, useSearchParams } from "next/navigation"
import { useInView } from "react-intersection-observer"

import styles from "./Timeline.module.scss"

const Timeline = ({ items }: { items: ReactNode[] }) => {
  const pathName = usePathname()
  const searchParams = useSearchParams()
  const prevItemsLengthRef = useRef<number>(0)
  const newItemsCountRef = useRef<number>(0)

  const { ref: timelineListRef, inView } = useInView({
    triggerOnce: true,
    threshold: 0,
  })

  const prefersReducedMotion = useMemo(() => {
    if (typeof window !== "undefined") {
      return window.matchMedia("(prefers-reduced-motion: reduce)").matches
    }
  }, [])

  const slide = ({ itemSelector }: { itemSelector: string }): void => {
    if (prefersReducedMotion) {
      const timelineList = document?.querySelectorAll(itemSelector)
      timelineList?.forEach((item) => {
        ;(item as HTMLElement).style.opacity = "1"
      })

      const timelineListItem = document?.querySelectorAll(itemSelector)
      timelineListItem?.forEach((item) => {
        ;(item as HTMLElement).style.opacity = "1"
      })
    } else {
      animate([
        [".timelineList", { opacity: [0, 1] }, { duration: 0 }],
        [
          itemSelector,
          { y: [20, 0], opacity: [0, 1] },
          { delay: stagger(0.1), duration: 0.2 },
        ],
      ])
    }
  }

  useEffect(() => {
    if (!inView) {
      return
    }

    newItemsCountRef.current = Math.max(
      0,
      items.length - prevItemsLengthRef.current,
    )
    prevItemsLengthRef.current = items.length
    slide({ itemSelector: ".timelineListItem.new-item" })
  }, [items, pathName, searchParams, inView])

  useEffect(() => {
    inView && slide({ itemSelector: ".timelineListItem" })
  }, [inView])

  return (
    <div
      ref={timelineListRef}
      className={clsx("timelineList", styles.timelineList)}
    >
      <AnimatePresence initial={true}>
        {items.map((item, index) => (
          <motion.div
            key={index}
            className={clsx("timelineListItem", styles.timelineListItem, {
              "new-item": index >= items.length - newItemsCountRef.current,
            })}
            initial={
              index >= items.length - newItemsCountRef.current
                ? { opacity: 0, y: 20 }
                : false
            }
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.2 }}
          >
            {item}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}

export default Timeline
