// Platform-specific exports for SignIn
// Bundler will automatically resolve to .web.tsx or .native.tsx
export { default } from "./SignIn.web"
export type { DesktopAuthHandler } from "./SignIn.web"
