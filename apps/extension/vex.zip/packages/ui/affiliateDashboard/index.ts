import AffiliateDashboard from "./AffiliateDashboard"

export default AffiliateDashboard
