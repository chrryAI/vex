"use client"

import React, { useEffect, useState } from "react"
import { useMediaQuery } from "./hooks/useMediaQuery" // assuming you have this hook
import clsx from "clsx"
import { CircleArrowLeft, Menu, X } from "lucide-react" // or your preferred icons
import { FRONTEND_URL } from "./utils"
import Img from "./Img"
import Logo from "./Logo"

interface ResponsiveDrawerProps {
  children: React.ReactNode
  className?: string
  onLogoClick?: () => void
}

export default function ResponsiveDrawer({
  children,
  className,
  onLogoClick,
}: ResponsiveDrawerProps) {
  const isMobile = useMediaQuery("only screen and (max-width: 800px)")
  const [isOpen, setIsOpen] = useState(false)

  // Set initial state based on device type
  useEffect(() => {
    setIsOpen(!isMobile) // Open by default on desktop, closed on mobile
  }, [isMobile])

  const toggleDrawer = () => {
    setIsOpen(!isOpen)
  }

  const closeDrawer = () => {
    setIsOpen(false)
  }

  return (
    <>
      {/* Mobile hamburger button */}
      {isMobile && (
        <button
          className={clsx("hamburger-btn", className)}
          onClick={toggleDrawer}
          style={{
            position: "fixed",
            top: "1rem",
            left: "1rem",
            zIndex: 1001,
          }}
        >
          <Menu size={20} />
        </button>
      )}

      {/* Mobile overlay */}
      {isMobile && isOpen && (
        <div
          className="drawer-overlay"
          onClick={closeDrawer}
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 999,
          }}
        />
      )}

      {/* Drawer */}
      <div
        className={clsx("responsive-drawer", className, {
          "drawer-open": isOpen,
          "drawer-closed": !isOpen,
          "drawer-mobile": isMobile,
          "drawer-desktop": !isMobile,
        })}
        style={{
          position: isMobile ? "fixed" : "static",
          top: 0,
          left: 0,
          height: isMobile ? "100vh" : "auto",
          minHeight: !isMobile ? "100vh" : "auto",
          width: "220px",
          borderRight: "1px dashed var(--shade-2)",
          backgroundColor: "var(--shade-1)",
          transform: isMobile
            ? isOpen
              ? "translateX(0)"
              : "translateX(-100%)"
            : "none",
          transition: "transform 0.3s ease-in-out",
          zIndex: 1000,
          overflowY: "auto",
          display: !isMobile || isOpen ? "block" : "none",
        }}
      >
        {/* Desktop minimize button */}
        {!isMobile && (
          <div
            style={{
              padding: 11.5,
            }}
          >
            {isOpen ? (
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <button className={clsx("link")} onClick={onLogoClick}>
                  <Logo size={28} />
                </button>
                <button
                  onClick={closeDrawer}
                  style={{
                    background: "none",
                    border: "none",
                  }}
                >
                  <X size={20} />
                </button>
                <button
                  className={clsx("link")}
                  onClick={closeDrawer}
                  style={{
                    marginLeft: "auto",
                  }}
                >
                  <CircleArrowLeft size={20} />
                </button>
              </div>
            ) : (
              <button className={clsx("link")} onClick={onLogoClick}>
                <Logo size={26} />
              </button>
            )}
          </div>
        )}

        {/* Mobile close button */}
        {isMobile && (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <h3 style={{ margin: 0, fontSize: "1.125rem", fontWeight: "600" }}>
              Menu
            </h3>
            <button
              onClick={closeDrawer}
              style={{
                background: "none",
                border: "none",
              }}
            >
              <X size={20} />
            </button>
          </div>
        )}

        {/* Drawer content */}
        <div style={{}}>{children}</div>
      </div>

      {/* CSS for minimized desktop state */}
      <style jsx>{`
        .drawer-desktop.drawer-closed {
          width: 60px !important;
          overflow: hidden;
        }

        .drawer-desktop.drawer-closed .drawer-content > * {
          opacity: 0;
          transition: opacity 0.2s ease-in-out;
        }

        .drawer-desktop.drawer-open .drawer-content > * {
          opacity: 1;
          transition: opacity 0.3s ease-in-out 0.1s;
        }

        @media (max-width: 768px) {
          .hamburger-btn:hover {
          }
        }

        /* Ensure drawer has proper background to hide HTML colors */
        .responsive-drawer {
        }
      `}</style>
    </>
  )
}
