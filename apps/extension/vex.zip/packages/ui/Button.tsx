"use client"

import { ReactNode, ButtonHTMLAttributes } from "react"
import { parseClassName } from "./utils/parseClassName"

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode
  className?: string
}

const Button = ({ children, className, style, ...rest }: ButtonProps) => {
  // Parse className to get inline styles for utility classes
  const parsedStyles = parseClassName(className)

  // Merge parsed styles with explicit style prop
  const mergedStyles = { ...parsedStyles, ...style }

  return (
    <button className={className} style={mergedStyles} {...rest}>
      {children}
    </button>
  )
}

export default Button
