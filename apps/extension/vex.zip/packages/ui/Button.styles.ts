/**
 * Generated from Button.module.scss
 * Auto-converted SCSS to Unified Styles
 *
 * Works on both web and native! 🎉
 */

export const ButtonStyleDefs = {
  button: {
    base: {
      padding: "0.5rem 0.75rem",
      backgroundColor: "#3b82f6",
      color: "#fff",
      border: "none",
      borderRadius: "1.25rem",
      display: "inline-flex",
      alignItems: "center",
      gap: "0.3125rem",
    },
    hover: {
      backgroundColor: "#06b6d4",
    },
    disabled: {
      opacity: 0.5,
      cursor: "default",
    },
  },
  link: {
    base: {
      textDecorationLine: "none",
      color: "#3b82f6",
    },
    hover: {
      color: "#06b6d4",
      textDecorationLine: "underline",
    },
  },
} as const

import { createUnifiedStyles } from "./styles/createUnifiedStyles"
import { useInteractiveStyles } from "./styles/useInteractiveStyles"

export const ButtonStyles = createUnifiedStyles(ButtonStyleDefs)

// Type for the hook return value
type ButtonStylesHook = {
  [K in keyof typeof ButtonStyleDefs]: ReturnType<typeof useInteractiveStyles>
}

// Create interactive style hooks
export const useButtonStyles = (): ButtonStylesHook => {
  return new Proxy({} as ButtonStylesHook, {
    get(_target: any, className: string | symbol): any {
      if (typeof className === "symbol") return undefined

      const styleDef =
        ButtonStyleDefs[className as keyof typeof ButtonStyleDefs]

      if (!styleDef) return { style: {}, handlers: {}, state: {} }

      // Check if this style has interactive states
      const hasInteractive = "base" in styleDef

      if (hasInteractive) {
        // Use interactive styles hook
        return useInteractiveStyles({
          baseStyle: (styleDef as any).base || {},
          hoverStyle: (styleDef as any).hover || {},
          activeStyle: (styleDef as any).active || {},
          focusStyle: (styleDef as any).focus || {},
          disabledStyle: (styleDef as any).disabled || {},
        })
      } else {
        // Return static styles
        return {
          style: styleDef,
          handlers: {},
          state: { isHovered: false, isPressed: false, isFocused: false },
        }
      }
    },
  })
}
