"use client"

import React, { useEffect } from "react"
import Skeleton from "./Skeleton"
import styles from "./LifeOS.module.scss"
import Img from "./Img"
import { FRONTEND_URL } from "./utils"
import clsx from "clsx"
import { useAppContext } from "./context/AppContext"
import { ArrowRight, Sparkles } from "./icons"
import Logo from "./Logo"
import { useApp, useAuth, useNavigationContext } from "./context/providers"
import { Div } from "./platform"
import { useLifeOSStyles } from "./LifeOS.styles"
import { useStyles } from "./context/StylesContext"

export default function LifeOS({ compact }: { compact?: boolean }) {
  const [selectedApp, setSelectedApp] = React.useState<
    "peach" | "bloom" | "atlas" | "vault"
  >("atlas")
  const { t } = useAppContext()
  const { track } = useAuth()

  const { router, setIsNewChat } = useNavigationContext()

  useEffect(() => {
    track({
      name: "LifeOS",
      props: {
        app: selectedApp,
      },
    })
  }, [setSelectedApp])

  const apps = [
    {
      name: "peach",
      title: "🍑 Peach",
      subtitle: "AI Social Network",
      description:
        "Connect with people through intelligent personality matching. Share experiences, find travel buddies, and build meaningful relationships powered by AI insights.",
      status: "in progress",
      features: ["Smart Matching", "Travel Connections", "Character Insights"],
    },
    {
      name: "bloom",
      title: "🌸 Bloom",
      subtitle: "AI Health & Sustainability Coach",
      description:
        "Track your wellness journey and environmental impact with AI-powered insights for a healthier you and planet.",
      status: "live",
      features: ["Health Tracking", "Carbon Footprint", "Wellness Insights"],
    },
    {
      name: "atlas",
      title: "🌍 Atlas",
      subtitle: "AI Travel Companion",
      description:
        "Your intelligent travel companion that learns your preferences and provides personalized recommendations for every journey.",
      status: "live",
      features: ["Smart Itineraries", "Local Insights", "Weather Integration"],
    },
    {
      name: "vault",
      title: "💰 Vault",
      subtitle: "Smart Finance",
      description:
        "AI-powered financial insights that help you make smarter money decisions. Track spending, optimize investments, and achieve your financial goals.",
      status: "planned",
      features: ["Expense Tracking", "Investment Insights", "Goal Planning"],
    },
  ]

  const app = apps.find((app) => app.name === selectedApp)

  const { lifeOSstyles, utilities } = useStyles()

  const { margin } = lifeOSstyles.lifeOS.style
  const render = () => {
    return (
      <Div
        style={{
          ...lifeOSstyles.lifeOS.style,
          margin: compact ? 0 : margin,
        }}
      >
        {!compact && (
          <div style={{ ...lifeOSstyles.header.style }}>
            <div style={{ ...lifeOSstyles.headerIcons.style }}>
              <Img
                showLoading={false}
                src={`${FRONTEND_URL}/images/pacman/space-invader.png`}
                alt="Space Invader"
                width={28}
                height={28}
              />
              <Img
                showLoading={false}
                src={`${FRONTEND_URL}/images/pacman/pacman.png`}
                alt="Pacman"
                width={28}
                height={28}
              />
              <Img
                showLoading={false}
                src={`${FRONTEND_URL}/icons/lifeOS-128.png`}
                alt="LifeOS"
                width={20}
                height={20}
              />
              <Img
                style={{ marginLeft: "auto" }}
                showLoading={false}
                src={`${FRONTEND_URL}/images/pacman/heart.png`}
                alt="Heart"
                width={28}
                height={28}
              />
            </div>
            <h1 className={styles.title}>
              <span className={styles.titleText}>
                {t("LifeOS - Your AI-Powered Life")}
              </span>
            </h1>
            <p className={styles.intro}>
              {t(
                "One platform, infinite possibilities. Experience the future of AI-integrated living with apps that understand you.",
              )}
            </p>
          </div>
        )}
        <div className={styles.createAgent}>
          <button
            onClick={() => {
              router.push("/?part=highlights")
            }}
            className="inverted"
          >
            <Sparkles size={16} color="var(--accent-1)" />
            {t("Create Your Agent")}
          </button>
        </div>
        <div className={styles.content}>
          <div className={styles.apps}>
            <div
              className={clsx(
                styles.app,
                selectedApp === "atlas" && styles.selected,
              )}
              onClick={() => setSelectedApp("atlas")}
            >
              <span className={clsx(styles.badge)}>{t("live")}</span>
              <Img
                src={`${FRONTEND_URL}/images/apps/atlas.png`}
                alt="Atlas"
                width={100}
                height={100}
              />
              <div className={styles.appInfo}>
                <span className={styles.appName}>🌍 Atlas</span>
                <span className={styles.appSubtitle}>
                  {t("AI Travel Companion")}
                </span>
              </div>
            </div>
            <div
              className={clsx(
                styles.app,
                selectedApp === "peach" && styles.selected,
              )}
              onClick={() => setSelectedApp("peach")}
            >
              <span className={clsx(styles.badge)}>{t("live")}</span>

              <Img
                src={`${FRONTEND_URL}/images/apps/peach.png`}
                alt="Peach"
                width={100}
                height={100}
              />
              <div className={styles.appInfo}>
                <span className={styles.appName}>🍑 Peach</span>
                <span className={styles.appSubtitle}>
                  {t("AI Social Network")}
                </span>
              </div>
            </div>
            <div
              className={clsx(
                styles.app,
                selectedApp === "bloom" && styles.selected,
              )}
              onClick={() => setSelectedApp("bloom")}
            >
              <span className={clsx(styles.badge)}>{t("live")}</span>
              <Img
                src={`${FRONTEND_URL}/images/apps/bloom.png`}
                alt="Bloom"
                width={100}
                height={100}
              />
              <div className={styles.appInfo}>
                <span className={styles.appName}>🌸 Bloom</span>
                <span className={styles.appSubtitle}>
                  {t("Health & Planet")}
                </span>
              </div>
            </div>

            <div
              className={clsx(
                styles.app,
                selectedApp === "vault" && styles.selected,
              )}
              onClick={() => setSelectedApp("vault")}
            >
              <span className={clsx(styles.badge)}>{t("live")}</span>
              <Img
                src={`${FRONTEND_URL}/images/apps/vault.png`}
                alt="Vault"
                width={100}
                height={100}
              />
              <div className={styles.appInfo}>
                <span className={styles.appName}>💰 Vault</span>
                <span className={styles.appSubtitle}>{t("Smart Finance")}</span>
              </div>
            </div>
          </div>

          <div key={selectedApp} className={styles.footer}>
            {app && (
              <div className={styles.appDetails}>
                <h3>{app.title}</h3>
                <p className={styles.subtitle}>{t(app.subtitle)}</p>
                <p className={styles.description}>{t(app.description)}</p>
                <div className={styles.features}>
                  <h4>{t("Key Features")}</h4>
                  <ul>
                    {app.features.map((feature, index) => (
                      <li className={styles.feature} key={index}>
                        <Sparkles
                          size={16}
                          color="var(--accent-1)"
                          fill="var(--accent-1)"
                        />
                        {t(feature)}
                      </li>
                    ))}
                    <li className={styles.feature}>
                      <button
                        onClick={() => router.push(`/${app.name}`)}
                        className={"link"}
                      >
                        <ArrowRight size={16} color="var(--accent-6)" />
                        {t("Try it now!")}
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
        {/* Hidden content for SEO - all apps details */}
        {!compact && (
          <div style={{ display: "none" }} className="seo-content">
            {apps.map((appItem) => (
              <section key={appItem.name}>
                <h2>{appItem.title}</h2>
                <h3>{t(appItem.subtitle)}</h3>
                <p>{t(appItem.description)}</p>
                <h4>{t("Key Features")}</h4>
                <ul>
                  {appItem.features.map((feature, index) => (
                    <li key={index}>{t(feature)}</li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}
        {!compact && (
          <div className={styles.tetris}>
            <div style={{ display: "flex", gap: "1rem" }}>
              <a
                href={`${FRONTEND_URL}`}
                className={clsx("link", styles.hamburgerButton)}
                onClick={(e) => {
                  if (e.metaKey || e.ctrlKey) {
                    return
                  }
                  e.preventDefault()
                  setIsNewChat(true)
                }}
              >
                <Logo size={24} /> Vex
              </a>
              <Img
                showLoading={false}
                src={`${FRONTEND_URL}/images/pacman/tetris1.png`}
                alt="Tetris 1"
                width={28}
                height={28}
              />
              <Img
                showLoading={false}
                src={`${FRONTEND_URL}/images/pacman/tetris2.png`}
                alt="Tetris 2"
                width={28}
                height={28}
              />
            </div>
            <span></span>
          </div>
        )}
      </Div>
    )
  }

  if (compact) {
    return render()
  }

  return <Skeleton>{render()}</Skeleton>
}
