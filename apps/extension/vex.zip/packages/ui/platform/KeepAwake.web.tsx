export function useKeepAwake() {
  // No-op for web
}
