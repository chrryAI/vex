// import { useKeepAwake as useExpoKeepAwake } from "expo-keep-awake"

export function useKeepAwake() {
  //   useExpoKeepAwake()
}
