/**
 * Cross-platform online status hook type declarations
 */

export function useOnlineStatus(): boolean
