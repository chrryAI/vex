export function useKeepAwake(): void
