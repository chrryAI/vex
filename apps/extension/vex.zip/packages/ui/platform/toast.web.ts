// Platform-agnostic toast for Web
import toast from "react-hot-toast"

export default toast
export { toast }
