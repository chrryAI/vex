/**
 * Generated from ResponsiveDrawer.module.scss
 * Auto-converted SCSS to Unified Styles
 *
 * Works on both web and native! 🎉
 */

export const ResponsiveDrawerStyleDefs = {
  drawerClosed: {
    width: 60,
    overflow: "hidden",
  },
} as const

import { createUnifiedStyles } from "./styles/createUnifiedStyles"
import { createStyleHook } from "./styles/createStyleHook"

export const ResponsiveDrawerStyles = createUnifiedStyles(
  ResponsiveDrawerStyleDefs,
)

// Type for the hook return value
type ResponsiveDrawerStylesHook = {
  [K in keyof typeof ResponsiveDrawerStyleDefs]: {
    className?: string
    style?: Record<string, any>
  }
}

// Create the style hook using the factory
export const useResponsiveDrawerStyles =
  createStyleHook<ResponsiveDrawerStylesHook>(ResponsiveDrawerStyles)
