export { default } from "./SwipeableTimeControl.web"
