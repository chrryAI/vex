"use client"

import { useState, useEffect, useRef } from "react"
import Checkbox from "./Checkbox"
import clsx from "clsx"
import { CircleCheck, Cookie, LinkIcon, LocateOff, SettingsIcon } from "./icons"

import styles from "./Consent.module.scss"

import { checkIsExtension } from "./utils"
import { useAppContext } from "./context/AppContext"
import { useNavigationContext } from "./context/providers"

export const ANALYTICS_STORAGE_KEY = "cookieConsent"

export default function CookieConsent({
  className,
  ...props
}: {
  isVisible?: boolean
  className?: string
}) {
  const { t } = useAppContext()
  const { setIsMemoryConsentManageVisible } = useNavigationContext()
  const [isVisible, setIsVisible] = useState(props.isVisible)
  const [preferences, setPreferences] = useState<{
    analytics: boolean
    personalization: boolean
  }>({
    analytics: false,
    personalization: false,
  })

  const [manage, setManage] = useState(false)

  useEffect(() => {
    isVisible && manage
      ? setIsMemoryConsentManageVisible(manage)
      : setIsMemoryConsentManageVisible(false)
  }, [manage, isVisible])

  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setManage(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  useEffect(() => {
    const consent = localStorage.getItem(ANALYTICS_STORAGE_KEY)
    if (!consent) {
      setIsVisible(true)
    } else {
      setPreferences(JSON.parse(consent))
    }
  }, [])

  const handleAccept = (all: boolean = false) => {
    const newPreferences = {
      analytics: all || preferences.analytics,
      personalization: all || preferences.personalization,
    }

    localStorage.setItem(ANALYTICS_STORAGE_KEY, JSON.stringify(newPreferences))
    setPreferences(newPreferences)
    setIsVisible(false)

    window.dataLayer?.push({
      event: "consent_update",
      consent: "granted",
      analytics_storage: all || preferences.analytics ? "granted" : "denied",
      ad_storage: all || preferences.personalization ? "granted" : "denied",
      ad_user_data: all || preferences.personalization ? "granted" : "denied",
      ad_personalization:
        all || preferences.personalization ? "granted" : "denied",
    })

    window.gtag?.("consent", "update", {
      analytics_storage: all || preferences.analytics ? "granted" : "denied",
      ad_storage: all || preferences.personalization ? "granted" : "denied",
      ad_user_data: all || preferences.personalization ? "granted" : "denied",
      ad_personalization:
        all || preferences.personalization ? "granted" : "denied",
    })
  }

  const handleReject = () => {
    const newPreferences = {
      analytics: false,
      personalization: false,
    }

    localStorage.setItem(ANALYTICS_STORAGE_KEY, JSON.stringify(newPreferences))
    setPreferences(newPreferences)
    setIsVisible(false)

    window.dataLayer?.push({
      event: "consent_update",
      consent: "denied",
      analytics_storage: "denied",
      ad_storage: "denied",
      ad_user_data: "denied",
      ad_personalization: "denied",
    })

    window.gtag?.("consent", "update", {
      analytics_storage: "denied",
      ad_storage: "denied",
      ad_user_data: "denied",
      ad_personalization: "denied",
    })
  }

  if (checkIsExtension()) return null

  if (!isVisible) return null

  return (
    <div
      ref={containerRef}
      data-testid="cookie-consent-content"
      className={clsx(styles.cookieConsent, className, manage && styles.manage)}
    >
      <div className={styles.content}>
        <p>
          <span className={styles.cookie}>🍪</span>
          {t(
            "We use essential cookies to ensure basic functionality and analytics cookies to enhance your experience",
          )}
        </p>
      </div>
      {manage && (
        <div className={styles.options}>
          <Checkbox
            checked={preferences.analytics}
            onChange={(e) =>
              setPreferences((prev) => ({
                ...prev,
                analytics: e.target.checked,
              }))
            }
          >
            {t("Analytics")} ({t("Optional")})
          </Checkbox>

          <Checkbox
            checked={preferences.personalization}
            onChange={(e) =>
              setPreferences((prev) => ({
                ...prev,
                personalization: e.target.checked,
              }))
            }
          >
            {t("Personalization")} ({t("Optional")})
          </Checkbox>
        </div>
      )}
      <div className={styles.buttons}>
        {manage ? (
          <>
            {preferences.analytics || preferences.personalization ? (
              <button onClick={() => handleAccept()} className={styles.accept}>
                <CircleCheck size={16} /> {t("Accept")}
              </button>
            ) : (
              <>
                <button
                  onClick={handleReject}
                  className={clsx(styles.reject, "transparent")}
                >
                  <LocateOff size={16} /> {t("Reject")}
                </button>
                <button
                  onClick={() => window.open("/privacy")}
                  className={clsx(styles.reject)}
                >
                  <LinkIcon size={16} /> {t("Privacy")}
                </button>
              </>
            )}
          </>
        ) : (
          <>
            <button
              data-testid="manage-button"
              onClick={() => setManage(true)}
              className={clsx(styles.reject, "transparent")}
            >
              <Cookie size={16} /> {t("Manage")}
            </button>
            <button
              data-testid="accept-all-button"
              onClick={() => handleAccept(true)}
              className={clsx(styles.accept)}
            >
              <CircleCheck size={16} /> {t("Accept All")}
            </button>
          </>
        )}
      </div>
    </div>
  )
}
